﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication3
{
    public class Watch
    {
        public string WatchID { get; set; }
        public string Name { get; set; }
        public decimal UnitPrice { get; set; }
        public int DiscountQuantity { get; set; }
        public decimal DiscountPrice { get; set; }
    }
}
